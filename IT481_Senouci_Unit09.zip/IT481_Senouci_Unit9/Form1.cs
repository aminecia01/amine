﻿using IT481_Senouci_Unit2;
using System;
using System.Linq;
using System.Windows.Forms;

namespace IT481_Senouci_Unit02
{
    public partial class Form1 : Form
    {
        private DB database;

        public Form1()
        {
            InitializeComponent();
            // Ensure that the event handlers are set up for buttons 1 to 7
            button1.Click += new EventHandler(button1_Click);
            button2.Click += new EventHandler(button2_Click);
            button3.Click += new EventHandler(button3_Click);
            button4.Click += new EventHandler(button4_Click);
            button5.Click += new EventHandler(button5_Click);
            button6.Click += new EventHandler(button6_Click);
            button7.Click += new EventHandler(button7_Click);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Initialize the database object with the connection string
            string user = TextBox1.Text;
            string password = TextBox2.Text;
            string server = TextBox3.Text;
            string databaseName = TextBox4.Text;

            if (string.IsNullOrEmpty(user) || string.IsNullOrEmpty(password) ||
                string.IsNullOrEmpty(server) || string.IsNullOrEmpty(databaseName))
            {
                MessageBox.Show("You must enter user name, password, server, and database values");
            }
            else
            {
                // Password Length Check
                if (password.Length < 12)
                {
                    MessageBox.Show("Password length must be 12 characters or more");
                }
                else
                {
                    // Password Composition Check
                    bool isPasswordValid = CheckPasswordComposition(password);
                    if (!isPasswordValid)
                    {
                        MessageBox.Show("Password must contain alphanumeric and special characters");
                    }
                    else
                    {
                        database = new DB($"Server={server}\\SQLEXPRESS;" +
                                          "Trusted_Connection=True;" +
                                          $"User Id={user};" +
                                          $"Password={password};" +
                                          $"database={databaseName};" +
                                          "Connection timeout=30");
                        MessageBox.Show("ConnectionState information sent");
                    }
                }
            }
        }

        // Function to check password composition
        private bool CheckPasswordComposition(string password)
        {
            bool hasAlphaNumeric = password.Any(char.IsLetterOrDigit);
            bool hasSpecialChar = password.Any(ch => !char.IsLetterOrDigit(ch));

            return hasAlphaNumeric && hasSpecialChar;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Example: Get customer count
            string count = database.getCustomerCount();
            MessageBox.Show(count, "Customers count");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Example: Get customer names
            string names = database.getCustomerNames();
            MessageBox.Show(names, "Customer Names");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // Example: Get orders count
            string ordersCount = database.getOrdersCount();
            MessageBox.Show(ordersCount, "Orders Count");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            // Example: Get orders
            string ordersDetails = database.getOrders();
            MessageBox.Show(ordersDetails, "Orders Details");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            // Example: Get employee count
            string employeeCount = database.getEmployeeCount();
            MessageBox.Show(employeeCount, "Employee Count");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            // Example: Get employee last names
            string employeeLastNames = database.getEmployeeLastNames();
            MessageBox.Show(employeeLastNames, "Employee Last Names");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Your form load logic
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            // Your additional form load logic
        }

        // Additional event handlers for label clicks

        private void label1_Click(object sender, EventArgs e)
        {
            // Label click logic
        }

        private void label7_Click(object sender, EventArgs e)
        {
            // Label click logic
        }

        private void label5_Click(object sender, EventArgs e)
        {
            // Label click logic
        }

        private void label9_Click(object sender, EventArgs e)
        {
            // Label click logic
        }

        private void label8_Click(object sender, EventArgs e)
        {
            // Label click logic
        }

        private void label10_Click(object sender, EventArgs e)
        {
            // Label click logic
        }

        private void label11_Click(object sender, EventArgs e)
        {
            // Label click logic
        }
    }
}
