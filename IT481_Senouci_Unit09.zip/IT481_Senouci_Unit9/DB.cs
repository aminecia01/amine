﻿using System;
using System.Data.SqlClient;

namespace IT481_Senouci_Unit2
{
    internal class DB
    {
        string connectionString;
        SqlConnection cnn;

        public DB()
        {
            connectionString = "Server=LAPTOP-35MOJH30\\SQLEXPRESS;" +
                               "Trusted_Connection=True;" +
                               "database=Northwind;" +
                               "User Instance=false;" +
                               "Connection timeout=30";
        }

        // Constructor That takes DB Connection String 
        public DB(string conn)
        {
            connectionString = conn;
        }

        public string getCustomerCount()
        {
            Int32 count = 0;
            cnn = new SqlConnection(connectionString);

            try
            {
                cnn.Open();
                string countquery = "select count(*) from dbo.Customers;";
                SqlCommand cmd = new SqlCommand(countquery, cnn);
                count = Convert.ToInt32(cmd.ExecuteScalar());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                if (cnn.State == System.Data.ConnectionState.Open)
                {
                    cnn.Close();
                }
            }
            return count.ToString();
        }

        public string getCustomerNames()
        {
            string names = "None";
            SqlDataReader dataReader = null;

            try
            {
                cnn = new SqlConnection(connectionString);
                cnn.Open();
                string counterquery = "Select Companyname from customers;";
                SqlCommand cmd = new SqlCommand(counterquery, cnn);
                dataReader = cmd.ExecuteReader();

                while (dataReader.Read())
                {
                    try
                    {
                        names = names + dataReader.GetValue(0) + "\n";
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                if (dataReader != null)
                {
                    dataReader.Close();
                }
                if (cnn.State == System.Data.ConnectionState.Open)
                {
                    cnn.Close();
                }
            }
            return names;
        }

        public string getOrdersCount()
        {
            Int32 Count = 0;
            cnn = new SqlConnection(connectionString);

            try
            {
                cnn.Open();
                string counterquery = "select count(*) from dbo.Orders;";
                SqlCommand cmd = new SqlCommand(counterquery, cnn);
                Count = Convert.ToInt32(cmd.ExecuteScalar());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                if (cnn.State == System.Data.ConnectionState.Open)
                {
                    cnn.Close();
                }
            }
            return Count.ToString();
        }

        public string getOrders()
        {
            string orderDetails = "None";
            SqlDataReader dataReader = null;

            try
            {
                cnn = new SqlConnection(connectionString);
                cnn.Open();
                string orderQuery = "SELECT OrderID, CustomerID, OrderDate FROM dbo.Orders;";
                SqlCommand cmd = new SqlCommand(orderQuery, cnn);
                dataReader = cmd.ExecuteReader();

                while (dataReader.Read())
                {
                    orderDetails += $"OrderID: {dataReader.GetInt32(0)}, CustomerID: {dataReader.GetString(1)}, OrderDate: {dataReader.GetDateTime(2)}\n";
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                if (dataReader != null)
                {
                    dataReader.Close();
                }
                if (cnn.State == System.Data.ConnectionState.Open)
                {
                    cnn.Close();
                }
            }
            return orderDetails;
        }

        public string getEmployeeCount()
        {
            Int32 count = 0;
            cnn = new SqlConnection(connectionString);

            try
            {
                cnn.Open();
                string countQuery = "SELECT COUNT(*) FROM dbo.Employees;";
                SqlCommand cmd = new SqlCommand(countQuery, cnn);
                count = Convert.ToInt32(cmd.ExecuteScalar());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                if (cnn.State == System.Data.ConnectionState.Open)
                {
                    cnn.Close();
                }
            }
            return count.ToString();
        }

        public string getEmployeeLastNames()
        {
            string lastNames = "None";
            SqlDataReader dataReader = null;

            try
            {
                cnn = new SqlConnection(connectionString);
                cnn.Open();
                string lastNameQuery = "SELECT LastName FROM Employees;";
                SqlCommand cmd = new SqlCommand(lastNameQuery, cnn);
                dataReader = cmd.ExecuteReader();

                while (dataReader.Read())
                {
                    lastNames += dataReader.GetString(0) + "\n";
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                if (dataReader != null)
                {
                    dataReader.Close();
                }
                if (cnn.State == System.Data.ConnectionState.Open)
                {
                    cnn.Close();
                }
            }
            return lastNames;
        }
    }
}